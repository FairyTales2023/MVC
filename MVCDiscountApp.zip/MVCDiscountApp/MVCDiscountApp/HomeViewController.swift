//
//  ViewController.swift
//  MVCDiscountApp
//
//  Created by Avula,Mahitha on 3/30/23.
//

import UIKit

class HomeViewController: UIViewController {

    
    
    
    @IBOutlet weak var amountOL: UITextField!
    
    
    
    
    @IBOutlet weak var discRateOL: UITextField!
    
    var priceAfterDiscount = 0.0
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    
    @IBAction func btnClicked(_ sender: Any) {
        var amount=Double(amountOL.text!)
        print(amount!)
        var disc=Double(discRateOL.text!)
        print(disc!)
        priceAfterDiscount = amount!-(amount!*disc!/100)
        print(priceAfterDiscount)
        
        
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        //create a transition
        var transition=segue.identifier
        if(transition == "resultSegue"){
        //create destination
        var destination = segue.destination as! ResultViewController
            //assign values to resultviewcontroller
            destination.destinsationAmount = amountOL.text!
            destination.destinationDiscRate  = discRateOL.text!
            destination.result = String(priceAfterDiscount)
            
        
    }
    }
    
}

