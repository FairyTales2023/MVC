//
//  ViewController.swift
//  AnimationApp
//
//  Created by Mitta,Akhila on 3/28/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var ImageOutlet: UIImageView!
    
    
    @IBOutlet weak var happyOutlet: UIButton!
    
    @IBOutlet weak var sadOutlet: UIButton!
    
    
    @IBOutlet weak var angryOutlet: UIButton!
    
    
    @IBOutlet weak var shakeMeOutlet: UIButton!
    
    
    @IBOutlet weak var showOutlet: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    override func viewDidAppear(_ animated: Bool){
        //move the img outside of the screen view
        ImageOutlet.frame.origin.x = view.frame.maxX
        
        happyOutlet.frame.origin.x = view.frame.width
        
        sadOutlet.frame.origin.x = view.frame.width
        
        angryOutlet.frame.origin.x = view.frame.width
        
        shakeMeOutlet.frame.origin.x = view.frame.width
    }
    
    
    @IBAction func happyButtonClicked(_ sender: UIButton) {
        updateAndAnimate("happy")
    }
    
    
    @IBAction func sadButtonClicked(_ sender: UIButton) {
        updateAndAnimate("sad")
    }
    
    
    @IBAction func angryButtonClicked(_ sender: UIButton) {
        updateAndAnimate("angry")
    }
    
    
    @IBAction func shakeMeButtonClicked(_ sender: UIButton) {
        var width = ImageOutlet.frame.width
                
                width += 40
                
                var height = ImageOutlet.frame.height
                
                height = height + 40
                
                var x  =  ImageOutlet.frame.origin.x-20
                
                
                var y = ImageOutlet.frame.origin.y-20
                
                var largeFrame = CGRect(x: x, y: y, width: width, height: height)
                
                UIView.animate(withDuration: 1, delay: 0, usingSpringWithDamping: 0.4, initialSpringVelocity: 50, animations: {
                    self.ImageOutlet.frame = largeFrame
                })
                
            
    }
    
    
    @IBAction func showButtonClicked(_ sender: UIButton) {
        UIView.animate(withDuration: 1, animations: {
                    //Move all the compoenets to the center and disable show button
                    self.ImageOutlet.center.x = self.view.center.x
                    
                    self.happyOutlet.center.x = self.view.center.x;
                    
                    self.sadOutlet.center.x = self.view.center.x;
                    
                    self.angryOutlet.center.x = self.view.center.x;
                    
                    self.shakeMeOutlet.center.x = self.view.center.x
                    
                })
                
                showOutlet.isEnabled = false
                
            
    }
    
    
    
    
    
    func updateAndAnimate(_ imageName : String){
            
            //making the current image opaque.
            UIView.animate(withDuration: 1, animations: {
                self.ImageOutlet.alpha = 0
            })
            
            //Assign the new image with animation and make it transparent. (alpha = 1)
            
            UIView.animate(withDuration: 1, delay:0.5, animations: {
                self.ImageOutlet.alpha = 1
                self.ImageOutlet.image = UIImage(named: imageName)
            })
            

        }
}

