//
//  ViewController.swift
//  CoordinatesDemo2
//
//  Created by Avula,Mahitha on 3/23/23.
//

import UIKit

class ViewController: UIViewController {

    
    
    
    @IBOutlet weak var imageViewOutlet: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        let minX=imageViewOutlet.frame.minX
        let minY=imageViewOutlet.frame.minY
        print("(\(minX),\(minY))")
        let maxX=imageViewOutlet.frame.maxX
        let maxY=imageViewOutlet.frame.maxY
        print("(\(maxX),\(maxY))")
        let midX=imageViewOutlet.frame.midX
        let midY=imageViewOutlet.frame.midY
        print("(\(midX),\(midY))")
        //move the image  to upper left corner
//        imageViewOutlet.frame.origin.x=0
//        imageViewOutlet.frame.origin.y=0
        //move the image to upper right corner
//        imageViewOutlet.frame.origin.x = 414-100
//        imageViewOutlet.frame.origin.y=0
            //move the image to lower left corner
        imageViewOutlet.frame.origin.x = 0
        imageViewOutlet.frame.origin.y = 896-100
        //move the image to lower right corner
        imageViewOutlet.frame.origin.x=414-100
        imageViewOutlet.frame.origin.y=896-100
        //move the image to midpoint
        //midpoint is 414/2 -100
        //midpoint is 896/2 -100
        imageViewOutlet.frame.origin.x = 157
        imageViewOutlet.frame.origin.y = 398
    }


}

