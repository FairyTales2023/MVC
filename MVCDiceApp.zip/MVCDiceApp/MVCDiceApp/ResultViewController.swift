//
//  ResultViewController.swift
//  MVCDiceApp
//
//  Created by Kshatriya,Srivyshnavi on 4/3/23.
//

import UIKit

class ResultViewController: UIViewController {
    
    
    @IBOutlet weak var player1ScoreOL: UITextField!
    
    @IBOutlet weak var player2ScoreOL: UITextField!
    
    @IBOutlet weak var player1CSOL: UITextField!
    
    @IBOutlet weak var player2CSOL: UITextField!
    
    
    var play1 = ""
    var play2 = ""
    var count1 : Int = 0
    var count2 : Int = 0
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        player1ScoreOL.text = player1ScoreOL.text!+"Total number of games \(play1) won: \(count1)"
        player2ScoreOL.text = player2ScoreOL.text!+"Total number of games \(play2) won: \(count2)"
        player1CSOL.text = player1CSOL.text!+"\(play1) current score : nil"
        player2CSOL.text = player2CSOL.text!+"\(play2) current score : nil"
    }
    
    @IBAction func rollDiceBtn(_ sender: UIButton) {
        
        let rand1 = Int.random(in: 1..<7)
        let rand2 = Int.random(in: 1..<7)
        if(rand1>rand2)
        {
            count1 = count1+1;
            
            player1ScoreOL.text = "Total number of games \(play1) won: \(count1)"
            player2ScoreOL.text = "Total number of games \(play2) won: \(count2)"
            player1CSOL.text = "\(play1) current score : \(rand1)"
            player2CSOL.text = "\(play2) current score : \(rand2)"
        }
        else if(rand2>rand1)
        {
            count2 = count2+1;
            
            player1ScoreOL.text = "Total number of games \(play1) won: \(count1)"
            player2ScoreOL.text = "Total number of games \(play2) won: \(count2)"
            player1CSOL.text = "\(play1) current score : \(rand1)"
            player2CSOL.text = "\(play2) current score : \(rand2)"
        }
        else
        {
            print("hoiii")
            if(rand1 == rand2){
               print("hjj")
                print(count2)
                print(count1)
                player1ScoreOL.text = "Total number of games \(play1) won: \(count1)"
                player2ScoreOL.text = "Total number of games \(play2) won: \(count2)"
                player1CSOL.text = "\(play1) current score : \(rand1)"
                player2CSOL.text = "\(play2) current score : \(rand2)"
            }
        }
        
        /*
         // MARK: - Navigation
         
         // In a storyboard-based application, you will often want to do a little preparation before navigation
         override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
         // Get the new view controller using segue.destination.
         // Pass the selected object to the new view controller.
         }
         */
        
    }
}
