//
//  ViewController.swift
//  MVCDiceApp
//
//  Created by Kshatriya,Srivyshnavi on 4/3/23.
//

import UIKit

class HomeViewController: UIViewController {
    
    @IBOutlet weak var player1OL: UITextField!
    
    
    @IBOutlet weak var player2OL: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func playDiceBtn(_ sender: UIButton) {
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var transition = segue.identifier
                      if transition == "gameSegue"{
                          var destination = segue.destination as! ResultViewController
                          destination.play1 = player1OL.text!
                          destination.play2 = player2OL.text!
            }
    }
}

