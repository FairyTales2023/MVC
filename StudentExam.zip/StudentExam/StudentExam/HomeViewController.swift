//
//  ViewController.swift
//  StudentExam
//
//  Created by Avula,Mahitha on 4/11/23.
//

import UIKit

class HomeViewController: UIViewController {
    
    
    
    @IBOutlet weak var courseOutlet: UITextField!
    
    
    @IBOutlet weak var idOutlet: UITextField!
    
    
    @IBOutlet weak var courseButton: UIButton!
    
    @IBOutlet weak var statLabel: UILabel!
    
    @IBOutlet weak var enrolloutlet: UIButton!
    
    var studenFound = CourseDetails()
   var isFound = true
     var studentArray = CoursesArray
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        courseButton.isHidden = true
        enrolloutlet.isHidden = true
    }


    @IBAction func CourseCheckButton(_ sender: UIButton) {
        var courseid = courseOutlet.text!
        
        for student in studentArray{
            if(courseid  == student.courseID){
                isFound =  true
                studenFound = student
            }
        }
        if isFound {
            statLabel.text = "\(courseid) is open for registration"
            imageOutlet.image = UIImage(named: "\(studenFound.courseImage)")
            enrolloutlet.isHidden = false
        }
        else{
            enrolloutlet.isHidden  = true
            statLabel.text = "\(courseid) is not found"
            imageOutlet.image = UIImage(named: "default")
            
        }
        
    }
    
    
    @IBOutlet weak var imageOutlet: UIImageView!
    
    
    
    @IBAction func enrollButton(_ sender: UIButton) {
    }
    
    
    @IBAction func courseLabelOutlet(_ sender: UITextField) {
        var course = courseOutlet.text!
        courseButton.isEnabled = true
        if(sender.text == "")
        {
            courseButton.isEnabled = false
            courseButton.isHidden = true
        }
        else{
            courseButton.isEnabled = true
            courseButton.isHidden = false
            
        }
    }
//    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
//        let transition = segue.identifier
//                if transition == "resultSegue"{
//                    //Create a destination of type studentInfoViewController
//                    let destination = segue.destination as! StudentInfoViewController
//
//                    //if student is exists in the array, we will assign the studentObj in the destination with "studentFound"
//                    if isStudent {
//                        destination.studentObj = studentFound
//                    }else{
//                        //if the given sid is not in the array, then the student is a guest!!
//                        //we set the boolean in the destination as true!!
//                        destination.guestUser = true
//                    }
//    }
    
}

