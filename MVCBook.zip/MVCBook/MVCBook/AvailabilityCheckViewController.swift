//
//  ViewController.swift
//  MVCBook
//
//  Created by Avula,Mahitha on 4/8/23.
//

import UIKit

class AvailabilityCheckViewController: UIViewController {

    
    
    @IBOutlet weak var usernameOutlet: UITextField!
    
    
    @IBOutlet weak var bookidOutlet: UITextField!
    
   
    
    
    @IBOutlet weak var statusOutlet: UILabel!
    
    
    
    
    @IBOutlet weak var homeImageOutlet: UIImageView!
    
    
    
    @IBOutlet weak var checkButton: UIButton!
    
    
    
    var BookFound = Book()
    var isFound = false
    
    
    var bookArray = booksArray
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        checkButton.isHidden = true
    }

    
    @IBAction func checkoutBookAction(_ sender: UIButton) {
        let id = bookidOutlet.text!
        for book in bookArray{
            //var id = bookidOutlet.text!
            if id == book.bookId{
                BookFound = book
                isFound = true
            }
        }
            if isFound{
                statusOutlet.text = "Book with ID  \(id) found"
               // homeImageOutlet.isHidden = false
                homeImageOutlet.image = UIImage(named: "\(BookFound.bookImage)")
                checkButton.isHidden = false
            }
            else{
                statusOutlet.text = "Book not found"
               // checkButton.isHidden = true
               // homeImageOutlet.isHidden = true
            }
        }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let  transition = segue.identifier
        if transition == "checkoutSegue"{
            let destination = segue.destination as! CheckoutConfirmationViewController
            if isFound{
                destination.bookobj = BookFound
                destination.stat = "\(usernameOutlet.text!),your checkout is  sucessfull!!!"
           }
//            destination.stat = "() is found sucessfully"
//            destination.resultImage = BookFound.bookImage
//            destination.Resultstatus = "\(bookArray.bookName)"
        }
    }
    
    

}

