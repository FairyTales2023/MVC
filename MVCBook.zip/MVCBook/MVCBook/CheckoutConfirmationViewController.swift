//
//  CheckoutConfirmationViewController.swift
//  MVCBook
//
//  Created by Avula,Mahitha on 4/8/23.
//

import UIKit

class CheckoutConfirmationViewController: UIViewController {
    
    
    
    @IBOutlet weak var Resultstatus: UILabel!
    
    
    @IBOutlet weak var bookNameOutlet: UILabel!
    
    var bookobj = Book()
    var stat = ""
    var name = ""
    var img = ""
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        Resultstatus.text = "\(stat)"
        bookNameOutlet.text = "\(bookobj.bookName)"
        resultImage.image = UIImage(named: "\(bookobj.bookImage)")
        UIView.animate(withDuration: 1, delay: 0, usingSpringWithDamping: 0.4, initialSpringVelocity: 50, animations: { [self] in
            self.resultImage.image = UIImage(named: "\(bookobj.bookImage)")
        })
    }
    

    @IBOutlet weak var resultImage: UIImageView!
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
